#include "XPLMPlugin.h"
#include "XPLMProcessing.h"
#include "XPLMDataAccess.h"
#include "XPLMMenus.h"
#include "XPLMUtilities.h"
#include "Protocol.hpp"
#include <arpa/inet.h>
#include <sys/socket.h>
#include <fcntl.h>
#include <unistd.h>
#include <chrono>
#include <algorithm>
#include <cstdio>

static int inputSocket = -1;
static bool enabled = false;
static XPLMMenuID menu = nullptr;
static int parentItem = -1;
static HoneycombFrame frame;
static std::chrono::steady_clock::time_point receivedAt;
static bool receivedAny = false;
static sockaddr_in sender{};
static XPLMDataRef axes[6]{};
static XPLMDataRef overrides[4]{};
static bool owned[4]{};

static void releaseOverride(int i) {
    if (owned[i]) { XPLMSetDatai(overrides[i], 0); owned[i] = false; }
}
static void releaseAll() { for (int i = 0; i < 4; i++) releaseOverride(i); }
static bool acquire(int i) {
    if (!overrides[i]) return false;
    if (owned[i]) return XPLMGetDatai(overrides[i]) == 1;
    if (XPLMGetDatai(overrides[i]) != 0) return false;
    XPLMSetDatai(overrides[i], 1); owned[i] = true; return true;
}
static void menuAction(void *, void *) {
    enabled = !enabled;
    XPLMCheckMenuItem(menu, 0, enabled ? xplm_Menu_Checked : xplm_Menu_Unchecked);
    if (!enabled) releaseAll();
}
static float flightLoop(float, float, int, void *) {
    for (int i = 0; i < 64; i++) {
        unsigned char bytes[128]; sockaddr_in from{}; socklen_t length = sizeof(from);
        ssize_t n = recvfrom(inputSocket, bytes, sizeof(bytes), 0, reinterpret_cast<sockaddr *>(&from), &length);
        if (n < 0) break;
        HoneycombFrame incoming;
        if (from.sin_addr.s_addr != htonl(INADDR_LOOPBACK) || !decodeHoneycomb(bytes, size_t(n), incoming)) continue;
        frame = incoming; sender = from; receivedAt = std::chrono::steady_clock::now(); receivedAny = true;
    }
    bool fresh = receivedAny && std::chrono::duration<double>(std::chrono::steady_clock::now() - receivedAt).count() <= 0.25;
    uint32_t mask = enabled && fresh ? frame.mask : 0, applied = 0;
    for (int i = 0; i < 3; i++) {
        if ((mask & (1u << i)) && axes[i] && acquire(i)) {
            XPLMSetDataf(axes[i], frame.values[i]); applied |= 1u << i;
        } else releaseOverride(i);
    }
    if ((mask & 8) && axes[3]) {
        int count = std::min(16, XPLMGetDatavf(axes[3], nullptr, 0, 0));
        if (count > 0) { float values[16]; std::fill(values, values + count, frame.values[3]); XPLMSetDatavf(axes[3], values, 0, count); applied |= 8; }
    }
    if ((mask & 48) == 48 && axes[4] && axes[5] && acquire(3)) {
        XPLMSetDataf(axes[4], frame.values[4]); XPLMSetDataf(axes[5], frame.values[5]); applied |= 48;
    } else releaseOverride(3);
    if (fresh) {
        unsigned char acknowledgement[12] = {'H','C','A','1'};
        writeNetwork32(acknowledgement + 4, applied); writeNetwork32(acknowledgement + 8, frame.sequence);
        sendto(inputSocket, acknowledgement, sizeof(acknowledgement), 0, reinterpret_cast<const sockaddr *>(&sender), sizeof(sender));
    }
    return -1;
}
PLUGIN_API int XPluginStart(char *name, char *signature, char *description) {
    std::snprintf(name, 256, "Honeycomb Input POC");
    std::snprintf(signature, 256, "local.honeycomb.input.poc");
    std::snprintf(description, 256, "Calibrated local Honeycomb input through the Xbox Hub");
    const char *names[] = {"sim/joystick/yoke_pitch_ratio", "sim/joystick/yoke_roll_ratio", "sim/joystick/yoke_heading_ratio",
        "sim/cockpit2/engine/actuators/throttle_ratio", "sim/cockpit2/controls/left_brake_ratio", "sim/cockpit2/controls/right_brake_ratio"};
    for (int i = 0; i < 6; i++) {
        axes[i] = XPLMFindDataRef(names[i]);
        int type = i == 3 ? xplmType_FloatArray : xplmType_Float;
        if (!axes[i] || !XPLMCanWriteDataRef(axes[i]) || !(XPLMGetDataRefTypes(axes[i]) & type)) {
            XPLMDebugString("Honeycomb Input: unavailable/incompatible control dataref: "); XPLMDebugString(names[i]); XPLMDebugString("\n"); axes[i] = nullptr;
        }
    }
    const char *overrideNames[] = {"sim/operation/override/override_joystick_pitch", "sim/operation/override/override_joystick_roll",
        "sim/operation/override/override_joystick_heading", "sim/operation/override/override_gearbrake"};
    for (int i = 0; i < 4; i++) {
        overrides[i] = XPLMFindDataRef(overrideNames[i]);
        if (!overrides[i] || !XPLMCanWriteDataRef(overrides[i]) || !(XPLMGetDataRefTypes(overrides[i]) & xplmType_Int)) overrides[i] = nullptr;
    }
    parentItem = XPLMAppendMenuItem(XPLMFindPluginsMenu(), "Honeycomb Input", nullptr, 1);
    menu = XPLMCreateMenu("Honeycomb Input", XPLMFindPluginsMenu(), parentItem, menuAction, nullptr);
    XPLMAppendMenuItem(menu, "Enable calibrated input", nullptr, 1); XPLMCheckMenuItem(menu, 0, xplm_Menu_Unchecked);
    return 1;
}
PLUGIN_API int XPluginEnable() {
    inputSocket = socket(AF_INET, SOCK_DGRAM, 0);
    if (inputSocket < 0) return 0;
    if (fcntl(inputSocket, F_SETFL, O_NONBLOCK) < 0) { close(inputSocket); inputSocket = -1; return 0; }
    sockaddr_in address{}; address.sin_family = AF_INET; address.sin_len = sizeof(address);
    address.sin_port = htons(49876); address.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
    if (bind(inputSocket, reinterpret_cast<sockaddr *>(&address), sizeof(address)) < 0) { close(inputSocket); inputSocket = -1; return 0; }
    enabled = false; receivedAny = false;
    XPLMRegisterFlightLoopCallback(flightLoop, -1, nullptr); return 1;
}
PLUGIN_API void XPluginDisable() {
    enabled = false; releaseAll();
    XPLMUnregisterFlightLoopCallback(flightLoop, nullptr);
    if (inputSocket >= 0) { close(inputSocket); inputSocket = -1; }
}
PLUGIN_API void XPluginStop() {
    releaseAll();
    if (menu) XPLMDestroyMenu(menu);
    if (parentItem >= 0) XPLMRemoveMenuItem(XPLMFindPluginsMenu(), parentItem);
}
PLUGIN_API void XPluginReceiveMessage(XPLMPluginID, int message, void *) {
    if (message == XPLM_MSG_PLANE_LOADED) { enabled = false; releaseAll(); receivedAny = false; XPLMCheckMenuItem(menu, 0, xplm_Menu_Unchecked); }
}
