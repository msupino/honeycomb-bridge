#pragma once
#include <array>
#include <cstdint>
#include <cstddef>
#include <cstring>
#include <cmath>

struct HoneycombFrame {
    uint32_t mask = 0;
    uint32_t sequence = 0;
    std::array<float, 6> values{};
};
inline uint32_t readNetwork32(const unsigned char *p) {
    return uint32_t(p[0]) << 24 | uint32_t(p[1]) << 16 | uint32_t(p[2]) << 8 | uint32_t(p[3]);
}
inline void writeNetwork32(unsigned char *p, uint32_t n) {
    p[0] = n >> 24; p[1] = n >> 16; p[2] = n >> 8; p[3] = n;
}
inline bool decodeHoneycomb(const unsigned char *data, size_t length, HoneycombFrame &frame) {
    if (length != 40 || std::memcmp(data, "HCB1", 4) || readNetwork32(data + 12)) return false;
    HoneycombFrame parsed;
    parsed.mask = readNetwork32(data + 4); parsed.sequence = readNetwork32(data + 8);
    if (parsed.mask & ~uint32_t(63)) return false;
    for (size_t i = 0; i < 6; i++) {
        uint32_t bits = readNetwork32(data + 16 + 4 * i); float value;
        std::memcpy(&value, &bits, sizeof(value));
        if (!std::isfinite(value) || value > 1 || value < (i < 3 ? -1 : 0)) return false;
        parsed.values[i] = value;
    }
    frame = parsed; return true;
}
