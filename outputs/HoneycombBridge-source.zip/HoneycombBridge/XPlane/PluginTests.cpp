#include "Plugin.cpp"
#include <cassert>
#include <deque>
#include <map>
#include <string>
#include <vector>
#include <limits>

struct MockRef { int type = xplmType_Float; int integer = 0; float value = 0; std::vector<float> array = {0,0}; };
static std::map<std::string, MockRef> references;
static std::deque<std::vector<unsigned char>> datagrams;
static uint32_t appliedMask = 0;
extern "C" {
XPLMDataRef XPLMFindDataRef(const char *name) {
    auto &ref = references[name];
    ref.type = std::strstr(name, "override/") ? xplmType_Int : std::strstr(name, "throttle_ratio") ? xplmType_FloatArray : xplmType_Float;
    return &ref;
}
int XPLMCanWriteDataRef(XPLMDataRef) { return 1; }
XPLMDataTypeID XPLMGetDataRefTypes(XPLMDataRef ref) { return static_cast<MockRef *>(ref)->type; }
int XPLMGetDatai(XPLMDataRef ref) { return static_cast<MockRef *>(ref)->integer; }
void XPLMSetDatai(XPLMDataRef ref, int value) { static_cast<MockRef *>(ref)->integer = value; }
void XPLMSetDataf(XPLMDataRef ref, float value) { static_cast<MockRef *>(ref)->value = value; }
int XPLMGetDatavf(XPLMDataRef ref, float *, int, int) { return int(static_cast<MockRef *>(ref)->array.size()); }
void XPLMSetDatavf(XPLMDataRef ref, float *values, int start, int count) { auto &array = static_cast<MockRef *>(ref)->array; for (int i=0;i<count;i++) array.at(start+i)=values[i]; }
XPLMMenuID XPLMFindPluginsMenu() { return reinterpret_cast<void *>(1); }
int XPLMAppendMenuItem(XPLMMenuID, const char *, void *, int) { return 0; }
XPLMMenuID XPLMCreateMenu(const char *, XPLMMenuID, int, XPLMMenuHandler_f, void *) { return reinterpret_cast<void *>(2); }
void XPLMCheckMenuItem(XPLMMenuID, int, XPLMMenuCheck) {}
void XPLMDestroyMenu(XPLMMenuID) {}
void XPLMRemoveMenuItem(XPLMMenuID, int) {}
void XPLMDebugString(const char *) {}
void XPLMRegisterFlightLoopCallback(XPLMFlightLoop_f, float, void *) {}
void XPLMUnregisterFlightLoopCallback(XPLMFlightLoop_f, void *) {}
ssize_t recvfrom(int, void *buffer, size_t capacity, int, sockaddr *address, socklen_t *) {
    if (datagrams.empty()) return -1;
    auto packet = datagrams.front(); datagrams.pop_front(); assert(packet.size() <= capacity);
    std::memcpy(buffer, packet.data(), packet.size());
    auto *source = reinterpret_cast<sockaddr_in *>(address); source->sin_addr.s_addr = htonl(INADDR_LOOPBACK);
    return ssize_t(packet.size());
}
ssize_t sendto(int, const void *buffer, size_t count, int, const sockaddr *, socklen_t) {
    assert(count == 12); appliedMask = readNetwork32(static_cast<const unsigned char *>(buffer) + 4); return ssize_t(count);
}
}
static std::vector<unsigned char> packet(uint32_t mask) {
    std::vector<unsigned char> data(40); std::memcpy(data.data(), "HCB1", 4); writeNetwork32(data.data()+4,mask);
    const float values[] = {-0.5f,0.5f,0,0.75f,0.25f,0.5f};
    for (int i=0;i<6;i++) { uint32_t bits; std::memcpy(&bits,&values[i],4);writeNetwork32(data.data()+16+4*i,bits); }
    return data;
}
int main() {
    char name[256], signature[256], description[256]; assert(XPluginStart(name,signature,description)==1);
    inputSocket = -1; enabled = true;
    datagrams.push_back(packet(63)); flightLoop(0,0,0,nullptr);
    assert(appliedMask==63 && XPLMGetDatai(overrides[0])==1 && XPLMGetDatai(overrides[3])==1);
    assert(static_cast<MockRef *>(axes[0])->value==-0.5f);
    assert(static_cast<MockRef *>(axes[3])->array[1]==0.75f);
    receivedAt=std::chrono::steady_clock::now()-std::chrono::seconds(1);flightLoop(0,0,0,nullptr);
    for (int i=0;i<4;i++) assert(XPLMGetDatai(overrides[i])==0);
    enabled=false;datagrams.push_back(packet(63));flightLoop(0,0,0,nullptr);assert(appliedMask==0);
    enabled=true;XPLMSetDatai(overrides[1],1);datagrams.push_back(packet(2));flightLoop(0,0,0,nullptr);
    assert(appliedMask==0 && XPLMGetDatai(overrides[1])==1 && !owned[1]);
    XPLMSetDatai(overrides[1],0);
    datagrams.push_back(packet(1));flightLoop(0,0,0,nullptr);assert(appliedMask==1);
    HoneycombFrame test;auto bad=packet(64);assert(!decodeHoneycomb(bad.data(),bad.size(),test));
    bad=packet(1);writeNetwork32(bad.data()+16,0x7fc00000);assert(!decodeHoneycomb(bad.data(),bad.size(),test));
    assert(!decodeHoneycomb(bad.data(),12,test));
    XPluginDisable();XPluginStop();
    for (int i=0;i<4;i++) assert(!owned[i]);
    std::puts("Plugin unit tests passed: decode, main-loop application, stale release, disabled state, override conflict, invalid values and shutdown.");
}
